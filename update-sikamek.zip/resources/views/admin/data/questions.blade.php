@extends('admin.layouts.app')
@section('title', 'Tambah Pertanyaan')
@section('content')
    <main class="app-main">
        <div class="app-content-header">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Row-->
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0">{{ $survey->title }}</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Survey</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Input Pertanyaan</li>
                        </ol>
                    </div>
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
        </div>

        <!--begin::App Content Body-->
        <div class="app-content">
            <!--begin::Container-->
            <div class="container-fluid">
                <div class="card card-warning card-outline mb-4">
                    <!--begin::Header-->
                    <div class="card-header">
                        <div class="card-title">Input Pertanyaan</div>
                        <div class="float-end">
                            <a href="{{ route('survey.index') }}" class="btn btn-secondary btn-sm"><i
                                    class="bi bi-arrow-left"></i> Kembali</a>
                        </div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Form-->
                    <form id="survey-form" action="{{ route('surveys.questions.store', $survey->slug) }}" method="POST">
                        @csrf

                        <div class="card-body">
                            <div id="questions-container">
                                <!-- Pertanyaan Pertama -->
                                <div class="question-item">
                                    <div class="row mb-3">
                                        <label for="inputEmail3" class="col-sm-2 col-form-label">1. Pertanyaan</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="questions[0][question_text]"
                                                required>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="inputPassword3" class="col-sm-2 col-form-label">Jawaban</label>
                                        <div class="col-sm-10">
                                            <div class="row g-3">
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        <span class="input-group-text">Score 1</span> <!-- Skor 1 -->
                                                        <input type="text" class="form-control"
                                                            name="questions[0][options][]" placeholder="Opsi 1" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        <span class="input-group-text">Score 2</span> <!-- Skor 2 -->
                                                        <input type="text" class="form-control"
                                                            name="questions[0][options][]" placeholder="Opsi 2" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        <span class="input-group-text">Score 3</span> <!-- Skor 3 -->
                                                        <input type="text" class="form-control"
                                                            name="questions[0][options][]" placeholder="Opsi 3" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        <span class="input-group-text">Score 4</span> <!-- Skor 4 -->
                                                        <input type="text" class="form-control"
                                                            name="questions[0][options][]" placeholder="Opsi 4" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr> <!-- Pemisah -->
                                </div>
                            </div>
                        </div>
                        <!--end::Body-->
                        <!--begin::Footer-->
                        <div class="card-footer">
                            <button type="submit" class="btn btn-warning">Simpan</button>
                            <button type="button" class="btn btn-secondary" id="add-question">Tambah Pertanyaan</button>
                        </div>
                        <!--end::Footer-->
                    </form>
                    <!--end::Form-->
                </div>
            </div>
        </div>
        <!--end::App Content Body-->
    </main>

    <script>
        let questionIndex = 1;

        document.getElementById('add-question').addEventListener('click', function() {
            const container = document.getElementById('questions-container');
            const newQuestion = document.createElement('div');
            newQuestion.classList.add('question-item');
            newQuestion.innerHTML = `
                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">${questionIndex + 1}. Pertanyaan</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="questions[${questionIndex}][question_text]" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Jawaban</label>
                    <div class="col-sm-10">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <div class="input-group">
                                                        <span class="input-group-text">Score 1</span>
                                <input type="text" class="form-control" name="questions[${questionIndex}][options][0]" placeholder="Opsi 1" required>
                            </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group">
                                                        <span class="input-group-text">Score 2</span>
                                <input type="text" class="form-control" name="questions[${questionIndex}][options][1]" placeholder="Opsi 2" required>
                            </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group">
                                                        <span class="input-group-text">Score 3</span>
                                <input type="text" class="form-control" name="questions[${questionIndex}][options][2]" placeholder="Opsi 3" required>
                            </div>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group">
                                                        <span class="input-group-text">Score 4</span>
                                <input type="text" class="form-control" name="questions[${questionIndex}][options][3]" placeholder="Opsi 4" required>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr> <!-- Pemisah -->
            `;
            container.appendChild(newQuestion);
            questionIndex++;
        });

        document.getElementById('survey-form').addEventListener('submit', function(event) {
            // Mencegah form dari submit default
            event.preventDefault();

            // Mendapatkan semua input fields
            const questionInputs = document.querySelectorAll('input[name^="questions"][name$="[question_text]"]');
            const optionInputs = document.querySelectorAll('input[name^="questions"][name$="[options]"]');

            // Variabel untuk mengecek apakah ada input yang kosong
            let isValid = true;

            // Memeriksa setiap input pertanyaan
            questionInputs.forEach((input, index) => {
                if (input.value.trim() === '') {
                    isValid = false;
                    alert(`Pertanyaan ${index + 1} tidak boleh kosong.`);
                }
            });

            // Memeriksa setiap input jawaban
            optionInputs.forEach((input, index) => {
                if (input.value.trim() === '') {
                    isValid = false;
                    alert(`Jawaban untuk pertanyaan ${Math.floor(index / 4) + 1} tidak boleh kosong.`);
                }
            });

            // Jika semua input valid, submit form
            if (isValid) {
                this.submit();
            }
        });
    </script>
@endsection
