@extends('admin.layouts.app')
@section('title', 'Daftar Pertanyaan')
@section('content')
    <main class="app-main">
        <div class="app-content-header">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Row-->
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0">Daftar Pertanyaan</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Survey</a></li>
                            <li class="breadcrumb-item active" aria-current="page">List Pertanyaan</li>
                        </ol>
                    </div>
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
        </div>



        <div class="app-content">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3 class="card-title">{{ $survey->title }}</h3>
                                <div class="float-end">
                                    <a href="{{ route('surveys.questions.index', $survey->slug) }}"
                                        class="btn btn-success btn-sm"><i class="bi bi-plus"></i>Tambah Pertanyaan</a>

                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Pertanyaan</th>
                                            <th>Opsi Jawaban</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($questions as $index => $question)
                                            <tr>
                                                <td>{{ $index + 1 }}</td>
                                                <td>{{ $question->question_text }}</td>
                                                <td>
                                                    @foreach ($question->options as $option)
                                                        <li>{{ $option->option_text }}</li>
                                                    @endforeach

                                                </td>
                                                <!-- Tombol Edit -->
                                                <td>
                                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                                    data-bs-target="#editTechnicianModal{{ $question->id }}" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                    {{-- <a href="{{ route('questions.edit', [$survey->id, $question->id]) }}" class="btn btn-warning">Edit</a> --}}
                                                    <form id="delete-form-{{ $question->id }}"
                                                        action="{{ route('questions.destroy', $question->id) }}"
                                                        method="POST" style="display:inline;">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="button" class="btn btn-danger btn-sm"
                                                            onclick="confirmDelete({{ $question->id }})" title="Hapus">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>

                                            <div class="modal fade" id="editTechnicianModal{{ $question->id }}" tabindex="-1"
                                                aria-labelledby="editTechnicianModalLabel{{ $question->id }}" aria-hidden="true">
                                                <div class="modal-dialog" style="max-width: 900px; width: 90%;">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="editTechnicianModalLabel{{ $question->id }}">Edit Pertanyaan {{ $question->question_text }}</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form method="POST" action="{{ route('questions.update', $question->id) }}">
                                                            @csrf
                                                            @method('PUT')
                                                            <div class="modal-body">
                                                                <!-- Pertanyaan -->
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-md-3">
                                                                        <label for="question_text" class="form-label">Pertanyaan</label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="text" class="form-control"
                                                                            id="question_text" name="question_text"
                                                                            value="{{ $question->question_text }}" required>
                                                                    </div>
                                                                </div>
                                                                
                                                                <!-- Opsi Jawaban -->
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-md-3">
                                                                        <label for="options" class="form-label">Opsi Jawaban (pisahkan dengan koma)</label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="text" class="form-control"
                                                                            name="options" value="{{ implode(',', $question->options->pluck('option_text')->toArray()) }}" required>
                                                                        <small class="form-text text-muted">Masukkan opsi jawaban yang dipisahkan dengan koma.</small>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            {{-- <div class="card-footer clearfix">
                            <ul class="pagination pagination-sm m-0 float-end">
                                <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                            </ul>
                        </div> --}}
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
        </div>
    </main>
    
@endsection
