@extends('admin.layouts.app')
@section('title', 'Daftar Survey')
@section('content')
    <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Row-->
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0">Survey</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Survey</li>
                        </ol>
                    </div>
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3 class="card-title">Daftar Survey</h3>
                                <div class="float-end">
                                    <button class="btn btn-success btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#createHouseModal"
                                        @if ($surveys->where('is_active', 1)->count() > 0) disabled @endif>
                                        <i class="bi bi-plus"></i> Tambah Survey
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Judul</th>
                                            <th>Deskripsi</th>
                                            <th>Status</th>
                                            <th>Total Pertanyaan</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($surveys as $survey)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{ $survey->title }}</td>
                                                <td>{{ $survey->description }}</td>
                                                <td>{{ $survey->is_active ? 'Aktif' : 'Tidak Aktif' }}</td>
                                                <td>{{ $survey->questions->count() }}</td>

                                                <td>
                                                    <!-- Tombol Edit -->
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#editTechnicianModal{{ $survey->id }}"
                                                        title="Edit">
                                                        <i class="bi bi-pencil"></i>
                                                    </button>
                                                    <!-- Tombol Delete -->
                                                    <form id="delete-form-{{ $survey->id }}"
                                                        action="{{ route('survey.destroy', $survey->id) }}" method="POST"
                                                        style="display:inline;">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="button" class="btn btn-danger btn-sm"
                                                            onclick="confirmDelete({{ $survey->id }})" title="Hapus">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                    <a href="{{ route('surveys.questions.index', $survey->slug) }}"
                                                        class="btn btn-dark btn-sm"><i class="bi bi-plus"></i></a>
                                                    <a href="{{ route('questions.index', $survey->slug) }}"
                                                        class="btn btn-warning btn-sm"><i class="bi bi-list-check"></i></a>


                                                </td>
                                            </tr>
                                            <!-- Modal Edit Admin -->
                                            <div class="modal fade" id="editTechnicianModal{{ $survey->id }}"
                                                tabindex="-1"
                                                aria-labelledby="editTechnicianModalLabel{{ $survey->id }}"
                                                aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"
                                                                id="editTechnicianModalLabel{{ $survey->id }}">Edit
                                                                Admin
                                                            </h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <form method="POST"
                                                            action="{{ route('survey.update', $survey->id) }}">
                                                            @csrf
                                                            @method('PUT')
                                                            <div class="modal-body">
                                                                <!-- Nama -->
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-md-3">
                                                                        <label for="name" class="form-label">Nama
                                                                            Survey</label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="text" class="form-control"
                                                                            id="name" name="title"
                                                                            value="{{ $survey->title }}" required>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-md-3">
                                                                        <label for="name"
                                                                            class="form-label">Deskripsi</label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <textarea name="description" id="" class="form-control" rows="3">{{ $survey->description }}</textarea>

                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3 align-items-center">
                                                                    <div class="col-md-3">
                                                                        <label for="name"
                                                                            class="form-label">Deskripsi</label>
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <select class="form-control" id="is_active"
                                                                            name="is_active" required>
                                                                            <option value="1"
                                                                                {{ $survey->is_active ? 'selected' : '' }}>
                                                                                Aktif</option>
                                                                            <option value="0"
                                                                                {{ !$survey->is_active ? 'selected' : '' }}>
                                                                                Tidak Aktif</option>
                                                                        </select>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Tutup</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Simpan</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            {{-- <div class="card-footer clearfix">
                                <ul class="pagination pagination-sm m-0 float-end">
                                    <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                                </ul>
                            </div> --}}
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
        </div>
        <!--end::App Content-->
    </main>

    <!-- Modal Create House -->
    <div class="modal fade" id="createHouseModal" tabindex="-1" aria-labelledby="createHouseModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createHouseModalLabel">Tambah Survey</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="addTicketForm" method="POST" action="{{ route('survey.store') }}">
                    @csrf
                    <div class="modal-body">
                        <!-- Nama -->
                        <div class="row mb-3 align-items-center">
                            <div class="col-md-3">
                                <label for="name" class="form-label">Nama Survey</label>
                            </div>
                            <div class="col-md-9">
                                <input type="text" class="form-control" id="name" name="title" required>
                            </div>
                        </div>
                        <div class="row mb-3 align-items-center">
                            <div class="col-md-3">
                                <label for="name" class="form-label">Deskripsi</label>
                            </div>
                            <div class="col-md-9">
                                <textarea name="description" id="" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="row mb-3 align-items-center">
                            <div class="col-md-3">
                                <label for="name" class="form-label">Status</label>
                            </div>
                            <div class="col-md-9">
                                <select class="form-control" id="is_active" name="is_active" required>
                                    <option value="">Pilih...</option>
                                    <option value="1">Aktif</option>
                                    <option value="0">Tidak Aktif</option>
                                </select>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
