<!--begin::Footer-->
<footer class="app-footer">
    <!--begin::To the end-->
    <div class="float-end d-none d-sm-inline">Ver 1.0.1</div>
    <!--end::To the end-->
    <!--begin::Copyright-->
    <strong>
        Made with <i class="fa-solid fa-heart" style="color: red; font-size: 1em;"></i> By Diskominfo Pasaman &copy; 2025   
    </strong>
    
    
    
    {{-- Dinas Komunikasi dan Informatika Kabupaten Pasaman --}}
    {{-- All rights reserved. --}}
    <!--end::Copyright-->
</footer>
<!--end::Footer-->
