<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Participant extends Model
{
    use HasFactory;

    /**
     * Kolom yang dapat diisi (mass assignable).
     *
     * @var array<string>
     */
    protected $fillable = [
        'nik',
        'full_name',
        'email',
        'gender',
        'age_group_id',
        'education_level_id',
        'occupation_id',
        'work_unit_id',
    ];

    /**
     * Relasi ke model AgeGroup.
     */
    public function ageGroup()
    {
        return $this->belongsTo(AgeGroup::class, 'age_group_id');
    }

    /**
     * Relasi ke model EducationLevel.
     */
    public function educationLevel()
    {
        return $this->belongsTo(EducationLevel::class, 'education_level_id');
    }

    /**
     * Relasi ke model Occupation.
     */
    public function occupation()
    {
        return $this->belongsTo(Occupation::class, 'occupation_id');
    }

    /**
     * Relasi ke model WorkUnit.
     */
    public function workUnit()
    {
        return $this->belongsTo(WorkUnit::class, 'work_unit_id');
    }

    public function responses()
    {
        return $this->hasMany(Response::class, 'participants_id');
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($participant) {
            $participant->uuid = (string) Str::uuid();
        });
    }
}
