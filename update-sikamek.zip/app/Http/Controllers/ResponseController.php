<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Response;

class ResponseController extends Controller
{
    public function store(Request $request)
    {
        // Validasi data jawaban
        $request->validate([
            'participant_id' => 'required|exists:participants,id',
            'survey_id' => 'required|exists:surveys,id',
            'responses' => 'required|array',
            'responses.*' => 'required|exists:options,id',
        ]);

        // Simpan setiap jawaban ke tabel responses
        foreach ($request->responses as $questionId => $optionId) {
            Response::create([
                'survey_id' => $request->survey_id,
                'participants_id' => $request->participant_id,
                'question_id' => $questionId,
                'option_id' => $optionId,
            ]);
        }

        // Redirect ke halaman terima kasih
        return redirect()->route('thankyou');
    }
}
