<?php

namespace App\Http\Controllers;

use App\Models\EducationLevel;
use Illuminate\Http\Request;

class EducationLevelController extends Controller
{
    public function index()
    {
        $educationLevels = EducationLevel::paginate(10);
        return view('admin.data.education_levels', compact('educationLevels'));
    }

    public function store(Request $request)
    {
        $request->validate(['level' => 'required|string|max:255']);
        EducationLevel::create($request->all());
        return redirect()->route('jenjang_pendidikan.index')->with('success', 'Data Berhasil Ditambahkan');
    }

    public function update(Request $request, EducationLevel $jenjang_pendidikan)
    {
        $request->validate(['level' => 'required|string|max:255']);
        $jenjang_pendidikan->update($request->all());
        return redirect()->route('jenjang_pendidikan.index')->with('success', 'Data Berhasil Di Perbarui');
    }

    public function destroy(EducationLevel $jenjang_pendidikan)
    {
        $jenjang_pendidikan->delete();
        return redirect()->route('jenjang_pendidikan.index')->with('success', 'Data Berhasil Dihapus');
    }
}
