<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WorkUnit;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function generateReport()
    {
        // Query untuk mengambil data laporan berdasarkan respons
        $laporan = WorkUnit::with(['participants.responses.option', 'participants.responses.question'])
            ->select(
                'work_units.name as opd',
                DB::raw('COUNT(DISTINCT responses.participants_id) as jumlah_participant'),
                DB::raw('SUM(options.score) as total_skor'),
                DB::raw('COUNT(DISTINCT responses.question_id) as jumlah_soal')
            )
            ->leftJoin('participants', 'work_units.id', '=', 'participants.work_unit_id')
            ->leftJoin('responses', 'participants.id', '=', 'responses.participants_id')
            ->leftJoin('options', 'responses.option_id', '=', 'options.id')
            ->groupBy('work_units.name')
            ->get();

        // Query untuk mengambil data responden berdasarkan pendidikan
        $respondenByPendidikan = DB::table('responses')
            ->select(
                'work_units.name as opd',
                'education_levels.level as pendidikan',
                DB::raw('COUNT(DISTINCT responses.participants_id) as jumlah_responden')
            )
            ->leftJoin('participants', 'responses.participants_id', '=', 'participants.id')
            ->leftJoin('work_units', 'participants.work_unit_id', '=', 'work_units.id')
            ->leftJoin('education_levels', 'participants.education_level_id', '=', 'education_levels.id')
            ->groupBy('work_units.name', 'education_levels.level')
            ->get()
            ->groupBy('opd'); // Kelompokkan berdasarkan OPD

        // Query untuk mengambil data responden berdasarkan pekerjaan
        $respondenByPekerjaan = DB::table('responses')
            ->select(
                'work_units.name as opd',
                'occupations.occupation as pekerjaan',
                DB::raw('COUNT(DISTINCT responses.participants_id) as jumlah_responden')
            )
            ->leftJoin('participants', 'responses.participants_id', '=', 'participants.id')
            ->leftJoin('work_units', 'participants.work_unit_id', '=', 'work_units.id')
            ->leftJoin('occupations', 'participants.occupation_id', '=', 'occupations.id')
            ->groupBy('work_units.name', 'occupations.occupation')
            ->get()
            ->groupBy('opd'); // Kelompokkan berdasarkan OPD

        $respondenByUmur = DB::table('responses')
            ->select(
                'work_units.name as opd',
                'age_groups.range as umur',
                DB::raw('COUNT(DISTINCT responses.participants_id) as jumlah_responden')
            )
            ->leftJoin('participants', 'responses.participants_id', '=', 'participants.id')
            ->leftJoin('work_units', 'participants.work_unit_id', '=', 'work_units.id')
            ->leftJoin('age_groups', 'participants.age_group_id', '=', 'age_groups.id')
            ->groupBy('work_units.name', 'age_groups.range')
            ->get()
            ->groupBy('opd');

        $respondenByJenisKelamin = DB::table('responses')
            ->select(
                'work_units.name as opd',
                'participants.gender as jenis_kelamin',
                DB::raw('COUNT(DISTINCT responses.participants_id) as jumlah_responden')
            )
            ->leftJoin('participants', 'responses.participants_id', '=', 'participants.id')
            ->leftJoin('work_units', 'participants.work_unit_id', '=', 'work_units.id')
            ->groupBy('work_units.name', 'participants.gender')
            ->get()
            ->groupBy('opd'); // Kelompokkan berdasarkan OPD

        // Gabungkan data laporan dengan data responden berdasarkan pendidikan, pekerjaan, umur, dan jenis kelamin
        $laporan = $laporan->map(function ($item) use ($respondenByPendidikan, $respondenByPekerjaan, $respondenByUmur, $respondenByJenisKelamin) {
            $item->pendidikan = $respondenByPendidikan[$item->opd] ?? collect();
            $item->pekerjaan = $respondenByPekerjaan[$item->opd] ?? collect();
            $item->umur = $respondenByUmur[$item->opd] ?? collect();
            $item->jenis_kelamin = $respondenByJenisKelamin[$item->opd] ?? collect();
            return $item;
        });

        // Mengambil daftar soal yang ada di database
        $daftarSoal = DB::table('questions')
            ->select('id', 'question_text')
            ->get();

        // Mengambil data rata-rata nilai per soal untuk setiap OPD
        $soalData = DB::table('responses')
            ->select(
                'work_units.name as opd',
                'responses.question_id',
                DB::raw('AVG(options.score) as rata_rata_nilai')
            )
            ->leftJoin('participants', 'responses.participants_id', '=', 'participants.id')
            ->leftJoin('work_units', 'participants.work_unit_id', '=', 'work_units.id')
            ->leftJoin('options', 'responses.option_id', '=', 'options.id')
            ->groupBy('work_units.name', 'responses.question_id')
            ->get()
            ->groupBy('opd'); // Kelompokkan berdasarkan OPD

        // Gabungkan data laporan dengan data rata-rata nilai per soal
        $laporan = $laporan->map(function ($item) use ($soalData) {
            $item->soal = $soalData[$item->opd] ?? collect(); // Tambahkan data soal ke setiap OPD
            return $item;
        });

        // Menghitung IKM dan Mutu Pelayanan berdasarkan rata-rata nilai per soal
        $laporan = $laporan->map(function ($item) {
            $totalSkor = $item->soal->sum('rata_rata_nilai'); // Total skor dari rata-rata nilai per soal
            $jumlahSoal = $item->soal->count(); // Jumlah soal
            $item->ikm = $this->hitungIKM($totalSkor, $jumlahSoal);
            $item->mutu_pelayanan = $this->tentukanMutuPelayanan($item->ikm);
            return $item;
        });

        // Menghitung total OPD, rata-rata IKM (tidak termasuk yang 0), dan total responden
        $totalOPD = $laporan->count(); // Total OPD
        $totalResponden = $laporan->sum('jumlah_participant'); // Total responden (berdasarkan participant)

        // Menghitung rata-rata IKM (tidak termasuk yang 0)
        $laporanIKMNonNol = $laporan->filter(function ($item) {
            return $item->ikm > 0;
        });

        $rataRataIKM = $laporanIKMNonNol->isEmpty() ? 0 : $laporanIKMNonNol->avg('ikm');
        $mutuPelayananIkm = $this->mutuPelayananIkm($rataRataIKM);

        // Mengirimkan data ke view
        return view('report', compact('laporan', 'mutuPelayananIkm', 'totalOPD', 'rataRataIKM', 'totalResponden', 'daftarSoal'));
    }

    private function hitungIKM($totalSkor, $jumlahSoal)
    {
        if ($jumlahSoal > 0) {
            return ($totalSkor / $jumlahSoal) * 25; // Skala 0-100
        }
        return 0; // Jika tidak ada soal, IKM adalah 0
    }

    private function tentukanMutuPelayanan($ikm)
    {
        if ($ikm >= 89) {
            return 'Sangat Baik';
        } elseif ($ikm >= 80) {
            return 'Baik';
        } elseif ($ikm >= 70) {
            return 'Kurang Baik';
        } elseif ($ikm == 0) {
            return '-';
        } else {
            return 'Kurang';
        }
    }

    private function mutuPelayananIkm($rataRataIKM)
    {
        if ($rataRataIKM >= 89) {
            return 'Sangat Baik';
        } elseif ($rataRataIKM >= 80) {
            return 'Baik';
        } elseif ($rataRataIKM >= 70) {
            return 'Kurang Baik';
        } elseif ($rataRataIKM == 0) {
            return '-';
        } else {
            return 'Kurang';
        }
    }
}
