<?php

namespace App\Http\Controllers;

use App\Models\Occupation;
use Illuminate\Http\Request;

class OccupationController extends Controller
{
    public function index()
    {
        $occupations = Occupation::paginate(10);
        return view('admin.data.occupations', compact('occupations'));
    }

    public function store(Request $request)
    {
        $request->validate(['occupation' => 'required|string|max:255']);
        Occupation::create($request->all());
        return redirect()->route('pekerjaan.index')->with('success', 'Data Berhasil Ditambahkan');
    }

    public function update(Request $request, Occupation $pekerjaan)
    {
        $request->validate(['occupation' => 'required|string|max:255']);
        $pekerjaan->update($request->all());
        return redirect()->route('pekerjaan.index')->with('success', 'Data Berhasil Di Perbarui');
    }

    public function destroy(Occupation $pekerjaan)
    {
        $pekerjaan->delete();
        return redirect()->route('pekerjaan.index')->with('success', 'Data Berhasil Dihapus');
    }
}
