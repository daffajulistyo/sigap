<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use App\Models\AgeGroup;
use App\Models\Question;
use App\Models\Response;
use App\Models\WorkUnit;
use App\Models\Occupation;
use App\Models\Participant;
use Illuminate\Http\Request;
use App\Models\EducationLevel;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        // Ambil semua survei
        $surveys = Survey::get();

        // Ambil ID survei yang dipilih dari request
        $selectedSurveyId = $request->input('survey_id', $surveys->first()->id);

        // Ambil ID unit kerja yang dipilih dari request
        $selectedWorkUnitId = $request->input('work_unit_id');

        // Ambil total respons
        $totalResponses = Response::count();

        // Ambil total peserta
        $totalParticipants = Participant::count();

        // Ambil total survei aktif
        $totalActiveSurveys = Survey::count();

        // Ambil data untuk grafik pie (participant berdasarkan umur) dari survei yang dipilih
        $ageGroups = AgeGroup::withCount(['participants' => function ($query) use ($selectedSurveyId, $selectedWorkUnitId) {
            $query->whereHas('responses.survey', function ($q) use ($selectedSurveyId) {
                $q->where('id', $selectedSurveyId);
            });

            // Filter berdasarkan work_unit_id jika dipilih
            if ($selectedWorkUnitId) {
                $query->where('work_unit_id', $selectedWorkUnitId);
            }
        }])->get();

        // Ambil data untuk grafik pie (participant berdasarkan gender) dari survei yang dipilih
        $genderCounts = Participant::select('gender', DB::raw('count(*) as count'))
            ->whereHas('responses.survey', function ($query) use ($selectedSurveyId) {
                $query->where('id', $selectedSurveyId);
            })
            // Filter berdasarkan work_unit_id jika dipilih
            ->when($selectedWorkUnitId, function ($query) use ($selectedWorkUnitId) {
                return $query->where('work_unit_id', $selectedWorkUnitId);
            })
            ->groupBy('gender')
            ->get();

        $occupationCounts = Occupation::withCount(['participants' => function ($query) use ($selectedSurveyId, $selectedWorkUnitId) {
            $query->whereHas('responses.survey', function ($q) use ($selectedSurveyId) {
                $q->where('id', $selectedSurveyId);
            });

            // Filter berdasarkan work_unit_id jika dipilih
            if ($selectedWorkUnitId) {
                $query->where('work_unit_id', $selectedWorkUnitId);
            }
        }])->get();

        // Ambil data untuk grafik pie (participant berdasarkan education level) dari survei yang dipilih
        $educationLevelCounts = EducationLevel::withCount(['participants' => function ($query) use ($selectedSurveyId, $selectedWorkUnitId) {
            $query->whereHas('responses.survey', function ($q) use ($selectedSurveyId) {
                $q->where('id', $selectedSurveyId);
            });

            // Filter berdasarkan work_unit_id jika dipilih
            if ($selectedWorkUnitId) {
                $query->where('work_unit_id', $selectedWorkUnitId);
            }
        }])->get();

        // Ambil survei yang dipilih
        $selectedSurvey = Survey::find($selectedSurveyId);
        $surveyTitle = $selectedSurvey ? $selectedSurvey->title : 'Tidak ada survei aktif';

        // Ambil data untuk grafik batang (jawaban per pertanyaan) dari survei yang dipilih
        $questions = $selectedSurvey ? $selectedSurvey->questions()->with('options.responses')->get() : collect();

        // Kirim data ke view
        return view('admin.home.dashboard', compact(
            'totalResponses',
            'totalParticipants',
            'totalActiveSurveys',
            'ageGroups',
            'genderCounts',
            'questions',
            'surveyTitle',
            'surveys',
            'selectedSurveyId',
            'selectedWorkUnitId',
            'occupationCounts',
            'educationLevelCounts'
        ));
    }
}
