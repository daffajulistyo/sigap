<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('participants', function (Blueprint $table) {
            $table->id();
            $table->string('nik')->unique(); // Nomor Induk Kependudukan
            $table->string('full_name'); // Nama lengkap
            $table->string('email')->unique(); // Alamat email
            $table->enum('gender', ['Laki-Laki', 'Perempuan']); // Jenis kelamin
            $table->foreignId('age_group_id')->constrained('age_groups')->onDelete('cascade'); // Foreign key ke age_groups
            $table->foreignId('education_level_id')->constrained('education_levels')->onDelete('cascade'); // Foreign key ke education_levels
            $table->foreignId('occupation_id')->constrained('occupations')->onDelete('cascade'); // Foreign key ke occupations
            $table->foreignId('work_unit_id')->constrained('work_units')->onDelete('cascade'); // Foreign key ke work_units
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('participants');
    }
};
