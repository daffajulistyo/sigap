<?php

namespace Database\Seeders;

use App\Models\EducationLevel;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EducationLevelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $level = [
            'SD',
            'SMP',
            'SMA',
            'D3',
            'S1',
            'S2',
            'S3',
            'Lainnya',
        ];

        foreach ($level as $pendidikan) {
            EducationLevel::create(['level' => $pendidikan]);
        }
    }
}
