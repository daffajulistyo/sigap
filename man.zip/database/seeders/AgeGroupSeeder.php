<?php

namespace Database\Seeders;

use App\Models\AgeGroup;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AgeGroupSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $range = [
            '20 Kebawah',
            '21-30',
            '31-40',
            '41-50',
            '51-60',
            '61 Keatas',
        ];

        foreach ($range as $umur) {
            AgeGroup::create(['range' => $umur]);
        }
    }
}
