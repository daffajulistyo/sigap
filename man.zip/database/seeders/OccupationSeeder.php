<?php

namespace Database\Seeders;

use App\Models\Occupation;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class OccupationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $occupation = [
            'PNS',
            'TNI',
            'POLRI',
            'Dokter',
            'Guru',
            'Pengacara',
            'Insinyur',
            'Akuntan',
            'Wiraswasta',
            'Petani',
            'Nelayan',
            'Sopir',
            'Pilot',
            'Pramugari',
            'Perawat',
            'Apoteker',
            'Desainer',
            'Arsitek',
            'Programmer',
            'Penulis',
            'Lainnya'

        ];

        foreach ($occupation as $pekerjaan) {
            Occupation::create(['occupation' => $pekerjaan]);
        }
    }
}
