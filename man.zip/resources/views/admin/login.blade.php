<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login SIKAMEK</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="{{ asset('bootstrap/css/simpeg.css') }}">
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="icon" href="{{ asset('assets/img/paspas.png') }}" type="image/x-icon">

</head>

<body class="focusedform">
    <div class="verticalcenter">
        <h1 style="text-align:center;"><b style="color:#c00;">Login</b> SIKAMEK</h1>
        <h3 style="text-align:center;margin-top:-20px;">Kabupaten Pasaman</h3>
        <div class="panel panel-primary">
            <div class="panel-body">
                <h4 class="text-center" style="margin-bottom: 25px;">Silahkan Login </a></h4>
                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fas fa-user"></i></span>
                            <input type="text" id="username" class="form-control" placeholder="Username" name="username" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fas fa-lock"></i></span>
                            <input type="password" id="password" class="form-control" placeholder="Password" name="password" required>
                        </div>
                    </div>
                </div>
                <div class="panel-footer">
                    <div class="pull-right">
                        <input type="reset" name="reset" id="reset-btn" class="btn btn-default" value="Reset">
                        <input type="submit" name="submit" id="submit" class="btn btn-primary" value="Log In">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="{{ asset('bootstrap/js/simpeg.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script type="text/javascript">
        $(function() {
            $('#submit').on('click', function() {
                $(this).val("Mencoba Login...");
                $(this).addClass('disabled');
                $('#form-login').submit();
            });
        });

        $('#reset-btn').on('click', function() {
            $('#username').val(''); // Clear the username input
            $('#password').val(''); // Clear the password input
            $('#submit-btn').val('Log In'); // Reset the submit button text
            $('#submit-btn').removeClass('disabled'); // Remove disabled class
        });
    </script>
</body>

</html>
