<!--begin::Sidebar-->
<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <!--begin::Sidebar Brand-->
    <div class="sidebar-brand">
        <!--begin::Brand Link-->
        <a href="{{ route('dashboard') }}" class="brand-link">
            <!--begin::Brand Image-->
            <img src="{{ asset('assets/dist/assets/img/logo.png') }}" alt="AdminLTE Logo"
                class="brand-image opacity-75 shadow" />
            <!--end::Brand Image-->
            <!--begin::Brand Text-->
            <span class="brand-text fw-light">SIKAMEK</span>
            <!--end::Brand Text-->
        </a>
        <!--end::Brand Link-->
    </div>
    <!--end::Sidebar Brand-->

    <!--begin::Sidebar Wrapper-->
    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <!--begin::Sidebar Menu-->
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">

                <li class="nav-header">MAIN NAVIGATION</li>

                <li class="nav-item">
                    <a href="{{ route('dashboard') }}"
                        class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                        <i class="nav-icon bi bi-speedometer2"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-header">DATA MASTER</li>

                <li class="nav-item">
                    <a href="{{ route('unit_kerja.index') }}"
                        class="nav-link {{ request()->routeIs('unit_kerja.index') ? 'active' : '' }}">
                        <i class="nav-icon bi bi-building"></i>
                        <p>Unit Kerja</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('kelompok_umur.index') }}"
                        class="nav-link {{ request()->routeIs('kelompok_umur.index') ? 'active' : '' }}">
                        <i class="nav-icon bi bi-people"></i>
                        <p>Kelompok Umur</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('jenjang_pendidikan.index') }}"
                        class="nav-link {{ request()->routeIs('jenjang_pendidikan.index') ? 'active' : '' }}">
                        <i class="nav-icon bi bi-mortarboard"></i>
                        <p>Jenjang Pendidikan</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('pekerjaan.index') }}"
                        class="nav-link {{ request()->routeIs('pekerjaan.index') ? 'active' : '' }}">
                        <i class="nav-icon bi bi-briefcase"></i>
                        <p>Daftar Pekerjaan</p>
                    </a>
                </li>
                @can('super-admin-only')
                    <li class="nav-item">
                        <a href="{{ route('users.index') }}"
                            class="nav-link {{ request()->routeIs('users.index') ? 'active' : '' }}">
                            <i class="nav-icon bi bi-person-lines-fill"></i>
                            <p>Akun</p>
                        </a>
                    </li>
                @endcan
                <li class="nav-header">DATA SURVEY</li>

                <li class="nav-item">
                    <a href="{{ route('survey.index') }}"
                        class="nav-link {{ request()->routeIs('survey.index') || request()->routeIs('surveys.questions.index') || request()->routeIs('questions.index') ? 'active' : '' }}">
                        <i class="nav-icon bi bi-clipboard-data"></i>
                        <p>Survey</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('responden.index') }}"
                        class="nav-link {{ request()->routeIs('responden.index') ? 'active' : '' }}">
                        <i class="nav-icon bi bi-people"></i>
                        <p>Responden</p>
                    </a>
                </li>
                <li class="nav-header">AUTH</li>
                <li class="nav-item">
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="nav-icon bi bi-box-arrow-right"></i>
                        <p>Logout</p>
                    </a>
                </li>

                <!-- Add more navigation items here as needed -->

            </ul>
            <!--end::Sidebar Menu-->
        </nav>
    </div>
    <!--end::Sidebar Wrapper-->
</aside>
<!--end::Sidebar-->
