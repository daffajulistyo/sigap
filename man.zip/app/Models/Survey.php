<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Survey extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'description', 'is_active'];

    public function questions()
    {
        return $this->hasMany(Question::class);
    }

    public function responses()
    {
        return $this->hasMany(Response::class, 'participants_id');
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($survey) {
            $survey->slug = $survey->generateSlug($survey->title);
        });

        static::updating(function ($survey) {
            $survey->slug = $survey->generateSlug($survey->title);
        });
    }

    // Method to generate slug from title
    public function generateSlug($title)
    {
        // Generate a slug from the title
        $slug = Str::slug($title);

        // Check for uniqueness
        $originalSlug = $slug;
        $count = 1;

        while (self::where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $count;
            $count++;
        }

        return $slug;
    }
}
