<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use App\Models\AgeGroup;
use App\Models\WorkUnit;
use App\Models\Occupation;
use App\Models\Participant;
use Illuminate\Http\Request;
use App\Models\EducationLevel;

class ParticipantController extends Controller
{
    public function create()
    {
        $ageGroups = AgeGroup::all();
        $educationLevels = EducationLevel::all();
        $occupations = Occupation::all();
        $workUnits = WorkUnit::all();
        return view(
            'home.registration_survey',
            [
                'ageGroups' => $ageGroups,
                'educationLevels' => $educationLevels,
                'occupations' => $occupations,
                'workUnits' => $workUnits,
            ]
        );
    }

    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'nik' => 'required|string|unique:participants,nik',
            'nama' => 'required|string',
            'email' => 'required|email|unique:participants,email',
            'usia' => 'required|exists:age_groups,id',
            'jenis-kelamin' => 'required|in:laki-laki,perempuan',
            'pendidikan' => 'required|exists:education_levels,id',
            'pekerjaan' => 'required|exists:occupations,id',
            'unit-kerja' => 'required|exists:work_units,id',
        ]);

        // Simpan data ke database
        $participant = Participant::create([
            'nik' => $request->nik,
            'full_name' => $request->nama,
            'email' => $request->email,
            'gender' => $request->{'jenis-kelamin'},
            'age_group_id' => $request->usia,
            'education_level_id' => $request->pendidikan,
            'occupation_id' => $request->pekerjaan,
            'work_unit_id' => $request->{'unit-kerja'},
        ]);

        // Ambil survei yang aktif
        $activeSurvey = Survey::where('is_active', true)->first();

        // Redirect ke halaman kuis dengan menyertakan ID participant dan ID survei
        return redirect()->route('responden.isi-survey', ['participant' => $participant->uuid, 'survey' => $activeSurvey->slug]);
    }

    public function index()
    {
        $participants = Participant::paginate(10);
        return view('admin.data.participants', ['participants' => $participants]);
    }
}
