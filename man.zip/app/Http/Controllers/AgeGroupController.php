<?php

namespace App\Http\Controllers;

use App\Models\AgeGroup;
use Illuminate\Http\Request;

class AgeGroupController extends Controller
{
    public function index()
    {
        $ageGroups = AgeGroup::paginate(10);
        return view('admin.data.age_groups', compact('ageGroups'));
    }

    public function store(Request $request)
    {
        $request->validate(['range' => 'required|string|max:255']);
        AgeGroup::create($request->all());
        return redirect()->route('kelompok_umur.index')->with('success', 'Data Berhasil Ditambahkan');
    }

    public function update(Request $request, AgeGroup $kelompok_umur)
    {
        $request->validate(['range' => 'required|string|max:255']);
        $kelompok_umur->update($request->all());
        return redirect()->route('kelompok_umur.index')->with('success', 'Data Berhasil Di Perbarui');
    }

    public function destroy(AgeGroup $kelompok_umur)
    {
        $kelompok_umur->delete();
        return redirect()->route('kelompok_umur.index')->with('success', 'Data Berhasil Dihapus');
    }
}
