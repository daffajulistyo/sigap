<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use App\Models\AgeGroup;
use App\Models\Question;
use App\Models\Response;
use App\Models\Participant;
use App\Models\WorkUnit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        // Ambil semua survei
        $surveys = Survey::get();

        // Ambil ID survei yang dipilih dari request
        $selectedSurveyId = $request->input('survey_id', $surveys->first()->id);

        // Ambil total respons
        $totalResponses = Response::count();

        // Ambil total peserta
        $totalParticipants = Participant::count();

        // Ambil total survei aktif
        $totalActiveSurveys = Survey::count();

        // Ambil data untuk grafik pie (participant berdasarkan umur) dari survei yang dipilih
        $ageGroups = AgeGroup::withCount(['participants' => function ($query) use ($selectedSurveyId) {
            $query->whereHas('responses.survey', function ($q) use ($selectedSurveyId) {
                $q->where('id', $selectedSurveyId);
            });
        }])->get();

        // Ambil data untuk grafik pie (participant berdasarkan gender) dari survei yang dipilih
        $genderCounts = Participant::select('gender', DB::raw('count(*) as count'))
            ->whereHas('responses.survey', function ($query) use ($selectedSurveyId) {
                $query->where('id', $selectedSurveyId);
            })
            ->groupBy('gender')
            ->get();

        // Ambil survei yang dipilih
        $selectedSurvey = Survey::find($selectedSurveyId);
        $surveyTitle = $selectedSurvey ? $selectedSurvey->title : 'Tidak ada survei aktif';

        // Ambil data untuk grafik batang (jawaban per pertanyaan) dari survei yang dipilih
        $questions = $selectedSurvey ? $selectedSurvey->questions()->with('options.responses')->get() : collect();

        // Kirim data ke view
        return view('admin.home.dashboard', compact(
            'totalResponses',
            'totalParticipants',
            'totalActiveSurveys',
            'ageGroups',
            'genderCounts',
            'questions',
            'surveyTitle',
            'surveys',
            'selectedSurveyId'
        ));
    }

   
}
