<?php

namespace App\Http\Controllers;

use App\Models\Survey;
use App\Models\Question;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    // Menampilkan form untuk menambahkan pertanyaan
    public function create($surveyId)
    {
        $survey = Survey::where('slug', $surveyId)->firstOrFail();

        return view('admin.data.questions', compact('survey'));
    }

    // Menyimpan pertanyaan yang ditambahkan
    public function store(Request $request, Survey $survey)
    {
        $request->validate([
            'questions.*.question_text' => 'required|string|max:255',
            'questions.*.option_text' => 'required|string',
        ]);

        foreach ($request->questions as $questionData) {
            // Buat pertanyaan baru
            $question = $survey->questions()->create([
                'question_text' => $questionData['question_text'],
            ]);

            // Simpan opsi sebagai array atau model terpisah
            $options = explode(',', $questionData['option_text']);

            // Menetapkan skor otomatis berdasarkan urutan opsi
            foreach ($options as $index => $option) {
                // Skor otomatis: 1 untuk opsi pertama, 2 untuk opsi kedua, dst.
                $score = $index + 1; // Menambahkan 1 untuk memulai dari 1

                // Simpan opsi dengan skor yang sesuai
                $question->options()->create([
                    'option_text' => trim($option),
                    'score' => $score, // Menyimpan skor otomatis
                ]);
            }
        }

        return redirect()->route('questions.index', $survey->slug)->with('success', 'Pertanyaan berhasil ditambahkan.');
    }


    // Menampilkan daftar pertanyaan untuk survei tertentu
    public function index(Survey $survey)
    {
        $survey = Survey::where('slug', $survey->slug)->firstOrFail();
        $questions = $survey->questions()->with('options')->get();
        return view('admin.data.list_questions', compact('survey', 'questions'));
    }

    public function update(Request $request, Question $question)
{
    // Validasi input
    $request->validate([
        'question_text' => 'required|string|max:255',
        'options' => 'required|string', // Pastikan ini adalah string
    ]);

    // Memperbarui teks pertanyaan
    $question->update([
        'question_text' => $request->question_text,
    ]);

    // Mengambil opsi yang sudah ada
    $existingOptions = $question->options()->pluck('id')->toArray();

    // Mengambil opsi baru dari input
    $newOptions = explode(',', $request->options);

    // Menghapus opsi yang tidak lagi ada
    foreach ($existingOptions as $optionId) {
        if (!in_array($optionId, $newOptions)) {
            $question->options()->find($optionId)->delete();
        }
    }

    // Menyimpan opsi baru dengan skor otomatis
    foreach ($newOptions as $index => $optionText) {
        // Cek apakah opsi sudah ada
        $option = $question->options()->where('option_text', trim($optionText))->first();

        if ($option) {
            // Jika opsi sudah ada, tidak perlu membuat yang baru
            $option->update(['option_text' => trim($optionText), 'score' => $index + 1]); // Skor otomatis
        } else {
            // Jika opsi baru, buat opsi baru dengan skor
            $question->options()->create([
                'option_text' => trim($optionText),
                'score' => $index + 1, // Skor otomatis
            ]);
        }
    }

    return redirect()->route('questions.index', $question->survey->slug)->with('success', 'Pertanyaan berhasil diperbarui.');
}



    // Menghapus pertanyaan
    public function destroy(Question $question)
    {
        $surveyId = $question->survey_id;
        $question->delete();

        return redirect()->route('questions.index', $surveyId)->with('success', 'Pertanyaan berhasil dihapus.');
    }
}
