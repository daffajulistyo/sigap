<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WorkUnit;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function generateReport()
    {
        // Mengambil data dari tabel responses dan menghitung jumlah responden dan total skor
        $reports = WorkUnit::with(['participants.responses.option'])
            ->select(
                'work_units.name as opd',
                DB::raw('COUNT(responses.id) as number_of_respondents'),
                DB::raw('SUM(options.score) as total_score')
            )
            ->leftJoin('participants', 'work_units.id', '=', 'participants.work_unit_id')
            ->leftJoin('responses', 'participants.id', '=', 'responses.participants_id')
            ->leftJoin('options', 'responses.option_id', '=', 'options.id')
            ->groupBy('work_units.name')
            ->get();

        // Menghitung IKM dan Mutu Pelayanan
        $reports = $reports->map(function ($report) {
            $report->ikm = $this->calculateIKM($report->total_score, $report->number_of_respondents);
            $report->service_quality = $this->determineServiceQuality($report->ikm);
            return $report;
        });

        // Mengirimkan data ke view
        return view('report', compact('reports'));
    }

    private function calculateIKM($totalScore, $numberOfRespondents)
    {
        if ($numberOfRespondents > 0) {
            return ($totalScore / ($numberOfRespondents * 4)) * 100; // Skala 0-100
        }
        return 0; // Jika tidak ada responden, IKM adalah 0
    }

    private function determineServiceQuality($ikm)
    {
        if ($ikm >= 89) {
            return 'Sangat Baik';
        } elseif ($ikm >= 80) {
            return 'Baik';
        } elseif ($ikm >= 70) {
            return 'Kurang Baik';
        } else {
            return 'Kurang';
        }
    }
}
